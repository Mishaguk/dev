import './sass/main.scss';
import  './js/gallery.js';
